from django.http import HttpResponseRedirect
from django.shortcuts import render
from django.shortcuts import render
from .models import Registration




def index(request):
    if request.method == 'POST':
        Registration.objects.create(name=request.POST.get('Name_user'), password=request.POST.get('Password_user'))
    if request.POST.get('Name_user')=='Timur' and  request.POST.get('Password_user')=='123':
        return HttpResponseRedirect('http://127.0.0.1:8000/admin/')


    return render(request, 'index.html')
